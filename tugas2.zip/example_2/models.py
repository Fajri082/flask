class model22:
	def __init__(self):
		self.text = '<h2>Hello flask!</h2>'

	def getText(self):
		return self.text