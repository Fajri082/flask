function update1(){
    document.getElementById("p1").innerHTML="<h2> tidak ada apa apa disini </h2>";
}
