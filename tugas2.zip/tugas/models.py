class Model25:

	def __init__ (self, title1=None, text1=None, content1=None, title2=None, text2=None, 
		content2=None, title3=None, text3=None, content3=None):
		self.title1 = title1
		self.text1 = text1
		self.content1 = content1
		self.title2 = title2
		self.text2 = text2
		self.content2 = content2
		self.title3 = title3
		self.text3 = text3
		self.content3 = content3

	def setTitle1(self, title1):
		self.title1 = title1

	def getTitle1(self):
		return self.title1

	def setText1(self, text1):
		self.text1 = text1

	def getText1(self):
		return self.text1

	def setContent1(self, content1):
		self.content1 = content1

	def getContent1(self):
		return self.content1

	def setTitle2(self, title2):
		self.title2 = title2

	def getTitle2(self):
		return self.title2

	def setText2(self, text2):
		self.text2 = text2

	def getText2(self):
		return self.text2

	def setContent2(self, content2):
		self.content2 = content2

	def getContent2(self):
		return self.content2

	def setTitle3(self, title3):
		self.title3 = title3

	def getTitle3(self):
		return self.title3

	def setText3(self, text3):
		self.text3 = text3

	def getText3(self):
		return self.text3

	def setContent3(self, content3):
		self.content3 = content3

	def getContent3(self):
		return self.content3