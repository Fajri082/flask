function kali (a, b){
	return a * b;
}

function pangkat(a, b){
	return Math.pow(a, b);
}