function update1(){
    document.getElementById("p1").innerHTML="<h3>Film berdurasi 115 menit yang disutradarai Goro Taniguchi ini menceritakan tentang pertemuan Luffy, tokoh utama dalam anime maupun komik One Piece, dengan Uta. Uta adalah seorang diva yang sedang konser di Pulau music Elegia. Para bajak laut, marinir, dan semua penggemar Uta dari seluruh dunia berkumpul di pulau itu.";
}
