class model24:
	def __init__ (self):
		self.text = 'hello flask!'

	def getText(self):
		return self.text